## Discord Menülü Rol Alma Bot Altyapısı!

## 📑 Bot Özellikleri

- [x] Menüden Rol Seçme
- [x] Embed Mesajlar
- [x] Tamamen Ayarlanabilir

## 📷 Görseller
![image](https://user-images.githubusercontent.com/93944142/208699781-ffd9c6a2-db3c-4275-8951-7f016820d4a2.png)
![image](https://user-images.githubusercontent.com/93944142/208700120-d78c59ab-4b9e-4305-ab68-d06709b76b74.png)
![image](https://user-images.githubusercontent.com/93944142/208700275-8c4ba451-c8ef-45fa-9526-7c7e20dba60e.png)
